
# SANpay App

**SANpay** is a Fintech Payment App offering Peer-to-Peer Transactions, Bill Payments, Cryptocurrency Payments, AI-based Microloans, and QR Code Payments.

## Features
- Peer-to-Peer Money Transfers
- Bill Payments
- Cryptocurrency Payment Integration
- AI-based Microloans
- QR Code Scanner Payments
- Multi-Language Support (Swahili, English)

## Installation

### Prerequisites
- Node.js (Latest LTS version)
- npm or yarn

### Clone Repository
```bash
git clone https://github.com/YourUsername/SANpay_App.git
cd SANpay_App
```

### Install Dependencies
```bash
npm install
```

### Start App
```bash
npm start
```

## Technologies Used
- React.js
- Tailwind CSS
- AI Microloan Model
- QR Code Scanner
- Multilingual Support

## License
This project is licensed under the MIT License.
