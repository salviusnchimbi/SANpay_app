
import { useState } from 'react';

export default function SANpayApp() {
  const [balance, setBalance] = useState(100000);
  const [language, setLanguage] = useState('en');

  const translations = {
    en: { welcome: 'Welcome to SANpay', balance: 'Balance' },
    sw: { welcome: 'Karibu SANpay', balance: 'Salio' },
  };

  const translate = (key) => translations[language][key] || key;

  return (
    <div>
      <h1>{translate('welcome')}</h1>
      <p>{translate('balance')}: Tsh {balance}</p>
      <select onChange={(e) => setLanguage(e.target.value)}>
        <option value="en">English</option>
        <option value="sw">Swahili</option>
      </select>
    </div>
  );
}
